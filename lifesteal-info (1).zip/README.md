# Lifesteal Info Dumper (Fabric 1.21.11, client-side)

Build: `gradle wrapper --gradle-version 9.2.1`, then `./gradlew build`.
Jar: build/libs/lifesteal-info-1.0.0.jar -> put in .minecraft/mods (with Fabric API).

Use:
1. Join mc.cwresports.lk. In the LOBBY run /lsinfo, wait 3 s. (report #1, copied to clipboard)
2. Enter Lifesteal (/lifesteal or the NPC), wait ~5 s, run /lsinfo again. (report #2)
3. Paste both reports to Claude. Files are also saved in .minecraft/lsinfo/.
The report includes a log of events (joins, sidebar title changes, messages) so the moment you entered Lifesteal is captured.
