package lk.cwresports.lsinfo;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Objects;

/**
 * Passive info collector. It only listens, plus /lsinfo sends ONE harmless "/balance" command.
 * Usage: /lsinfo  (collects ~3 s, then saves a report file and copies it to your clipboard)
 *        /lsinfo clear (clears the recorded event history)
 */
public class InfoClient implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("LifestealInfo");
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("HH:mm:ss.SSS");
    private static final DateTimeFormatter FILE_TS = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");
    private static final int MAX_EVENTS = 400;

    private final Deque<String> events = new ArrayDeque<>();
    private final List<String> probeMessages = new ArrayList<>();
    private boolean probing;
    private long probeEndsAt;
    private String lastTitle;
    private String lastDim;
    private int pollCooldown;
    private int linesCountdown = -1;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            ServerInfo si = client.getCurrentServerEntry();
            event("JOIN world/server (address=" + (si == null ? "none" : si.address) + ")");
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            event("DISCONNECT");
            lastTitle = null;
            lastDim = null;
            linesCountdown = -1;
        });

        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            try {
                String text = Report.clean(message.getString());
                event((overlay ? "ACTIONBAR: " : "MSG: ") + text);
                if (probing && !overlay) probeMessages.add(text);
            } catch (Throwable t) {
                LOG.error("message handler error", t);
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("lsinfo")
                        .executes(ctx -> {
                            startProbe(MinecraftClient.getInstance());
                            return 1;
                        })
                        .then(ClientCommandManager.literal("clear").executes(ctx -> {
                            events.clear();
                            ctx.getSource().sendFeedback(Text.literal("[LSInfo] events cleared"));
                            return 1;
                        }))));
    }

    private void event(String s) {
        events.addLast("[" + LocalTime.now().format(TS) + "] " + s);
        while (events.size() > MAX_EVENTS) events.removeFirst();
    }

    private void msg(MinecraftClient mc, String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("[LSInfo] " + s), false); // local only
    }

    private void startProbe(MinecraftClient mc) {
        ClientPlayNetworkHandler h = mc.getNetworkHandler();
        if (h == null || mc.player == null) return;
        probeMessages.clear();
        probing = true;
        probeEndsAt = System.currentTimeMillis() + 3000;
        h.sendChatCommand("balance");
        msg(mc, "Collecting info... (sent /balance, wait 3 seconds)");
    }

    private void onTick(MinecraftClient mc) {
        try {
            if (probing && System.currentTimeMillis() >= probeEndsAt) {
                probing = false;
                finishReport(mc);
            }

            if (--pollCooldown > 0) return;
            pollCooldown = 10;

            if (mc.world == null || mc.player == null) {
                lastTitle = null;
                lastDim = null;
                linesCountdown = -1;
                return;
            }
            String dim = mc.world.getRegistryKey().getValue().toString();
            if (!dim.equals(lastDim)) {
                event("DIMENSION: " + dim);
                lastDim = dim;
            }
            String title = Report.sidebarTitle(mc);
            if (!Objects.equals(title, lastTitle)) {
                event("SIDEBAR TITLE: " + (title == null ? "<none>" : "'" + title + "'"));
                lastTitle = title;
                linesCountdown = 3; // log the lines ~1s later, after they arrive
            }
            if (linesCountdown > 0 && --linesCountdown == 0) {
                event("SIDEBAR LINES: " + String.join(" | ", Report.sidebarLines(mc)));
            }
        } catch (Throwable t) {
            LOG.error("tick error", t);
        }
    }

    private void finishReport(MinecraftClient mc) {
        try {
            String report = Report.build(mc, events, probeMessages);
            Path dir = FabricLoader.getInstance().getGameDir().resolve("lsinfo");
            Files.createDirectories(dir);
            Path file = dir.resolve("report-" + FILE_TS.format(LocalDateTime.now()) + ".txt");
            Files.writeString(file, report);
            mc.keyboard.setClipboard(report);
            msg(mc, "Report saved: " + file + " - and copied to your clipboard. Paste it to Claude.");
        } catch (Throwable t) {
            LOG.error("report error", t);
            msg(mc, "Failed to build report: " + t);
        }
    }
}
