package lk.cwresports.lsinfo;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Builds the text report. Read-only: never changes anything in the game. */
public final class Report {
    private Report() {}

    // Same defaults the AutoPay mod uses, so you can see whether they would work.
    private static final Pattern BALANCE =
            Pattern.compile("(?i)(?:balance|bal|money|coins)\\D{0,20}?([0-9][0-9,]*(?:\\.[0-9]+)?)\\s*([kmbt])?(?![a-zA-Z])");
    private static final Pattern USERNAME = Pattern.compile("^\\.?[A-Za-z0-9_]{1,16}$");

    static String clean(String s) {
        if (s == null) return null;
        String stripped = Formatting.strip(s);
        return stripped == null ? s : stripped;
    }

    public static String sidebarTitle(MinecraftClient mc) {
        if (mc.world == null) return null;
        Scoreboard sb = mc.world.getScoreboard();
        ScoreboardObjective obj = sb.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
        if (obj == null) return null;
        return clean(obj.getDisplayName().getString());
    }

    public static List<String> sidebarLines(MinecraftClient mc) {
        List<String> out = new ArrayList<>();
        if (mc.world == null) return out;
        Scoreboard sb = mc.world.getScoreboard();
        ScoreboardObjective obj = sb.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
        if (obj == null) return out;
        List<ScoreboardEntry> entries = new ArrayList<>(sb.getScoreboardEntries(obj));
        entries.removeIf(ScoreboardEntry::hidden);
        entries.sort((a, b) -> Integer.compare(b.value(), a.value()));
        for (ScoreboardEntry e : entries) {
            Team team = sb.getScoreHolderTeam(e.owner());
            Text line = Team.decorateName(team, e.name());
            out.add(clean(line.getString()));
        }
        return out;
    }

    public static String build(MinecraftClient mc, Collection<String> events, List<String> probeMessages) {
        StringBuilder sb = new StringBuilder();
        sb.append("=== LIFESTEAL INFO REPORT ===\n");
        sb.append("time: ").append(LocalDateTime.now()).append('\n');
        sb.append("minecraft: 1.21.11\n");
        sb.append("my username (session): ").append(mc.getSession().getUsername()).append('\n');
        UUID selfId = mc.player != null ? mc.player.getUuid() : null;
        sb.append("my uuid: ").append(selfId).append("\n\n");

        // --- server ---
        sb.append("--- SERVER ---\n");
        ServerInfo info = mc.getCurrentServerEntry();
        if (info == null) {
            sb.append("not connected to a multiplayer server\n");
        } else {
            sb.append("address: ").append(info.address).append('\n');
            sb.append("name: ").append(info.name).append('\n');
        }
        if (mc.world != null) {
            sb.append("dimension id: ").append(mc.world.getRegistryKey().getValue()).append('\n');
        }

        // --- sidebar ---
        sb.append("\n--- SIDEBAR (scoreboard) ---\n");
        String title = sidebarTitle(mc);
        sb.append("title: ").append(title == null ? "<none>" : "'" + title + "'").append('\n');
        List<String> lines = sidebarLines(mc);
        sb.append("lines (").append(lines.size()).append("):\n");
        for (String l : lines) sb.append("  | ").append(l).append('\n');
        sb.append("title contains 'lifesteal': ")
                .append(title != null && title.toLowerCase(Locale.ROOT).contains("lifesteal")).append('\n');

        // --- tab list ---
        sb.append("\n--- TAB LIST (real name = GameProfile name) ---\n");
        ClientPlayNetworkHandler h = mc.getNetworkHandler();
        if (h == null) {
            sb.append("no network handler\n");
        } else {
            Collection<PlayerListEntry> list = h.getPlayerList();
            sb.append("entries: ").append(list.size()).append('\n');
            int ok = 0;
            for (PlayerListEntry e : list) {
                GameProfile p = e.getProfile();
                String real = p == null ? "<null>" : p.name();
                UUID id = p == null ? null : p.id();
                Text dn = e.getDisplayName();
                String display = dn == null ? "-" : clean(dn.getString());
                boolean self = id != null && id.equals(selfId);
                boolean valid = USERNAME.matcher(real).matches();
                if (!self && valid) ok++;
                sb.append("  ").append(real)
                        .append(" | uuid=").append(id)
                        .append(" | display='").append(display).append('\'')
                        .append(" | gm=").append(e.getGameMode())
                        .append(" | ping=").append(e.getLatency())
                        .append(self ? " | (YOU)" : "")
                        .append(valid ? "" : " | INVALID-NAME(would be skipped)")
                        .append(display.equals(real) || display.equals("-") ? "" : " | DISPLAY-DIFFERS(nick?)")
                        .append('\n');
            }
            sb.append("others that would be paid (excluding me, valid names): ").append(ok).append('\n');
        }

        // --- balance probe ---
        sb.append("\n--- /balance REPLY (system messages in the 3s after sending /balance) ---\n");
        if (probeMessages.isEmpty()) {
            sb.append("NO MESSAGES RECEIVED\n");
        } else {
            for (String m : probeMessages) {
                sb.append("  msg: ").append(m).append('\n');
                Matcher mm = BALANCE.matcher(m);
                if (mm.find()) {
                    String num = mm.group(1);
                    String suf = mm.groupCount() >= 2 ? mm.group(2) : null;
                    String parsed;
                    try {
                        parsed = new BigDecimal(num.replace(",", "")).toPlainString();
                    } catch (NumberFormatException ex) {
                        parsed = "?";
                    }
                    sb.append("     -> default regex MATCHED number=").append(num)
                            .append(" suffix=").append(suf).append(" parsed=").append(parsed).append('\n');
                } else {
                    sb.append("     -> default regex no match\n");
                }
            }
        }

        // --- events ---
        sb.append("\n--- RECENT EVENTS (oldest first) ---\n");
        for (String ev : events) sb.append(ev).append('\n');
        sb.append("=== END ===\n");
        return sb.toString();
    }
}
